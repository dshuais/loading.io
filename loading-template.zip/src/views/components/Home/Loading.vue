<script setup lang='ts'>
</script>
<template>
  粉红色小块：
  <Loading1 />

  黑色小点:
  <Loading2 />

  跷跷板信号：
  <Loading3 />

  跷跷板：
  <Loading4 />

  推方块：
  <Loading5 />

  穿插：
  <Loading6 />

  旋转：
  <Loading7 />

  经典：
  <Loading8 />

  爬梯：
  <Loading9 />

  弹弹弹：
  <Loading10 />

  隔山打牛：
  <Loading11 />

  层叠堆积：
  <Loading12 />

  svg---经典：
  <Loading13 />

  圆球---经典：
  <Loading14 />

  下雨：
  <Loading15 />

  多圈---经典：
  <Loading16 />

  圆球2---经典：
  <Loading17 style="margin-top: 10px;" />

  <div style="height: 50px; width:100%"></div>
</template>
<style lang='less' scoped></style>
