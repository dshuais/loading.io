<!--
 * @Author: dushuai
 * @Date: 2023-04-21 15:42:24
 * @LastEditors: dushuai
 * @LastEditTime: 2023-04-21 15:47:30
 * @description: Button
-->
<script setup lang='ts'>

</script>
<template>
  svg --- 节奏：
  <Button1 />
</template>
<style lang='less' scoped></style>
