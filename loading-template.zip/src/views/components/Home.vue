<!--
 * @Author: dushuai
 * @Date: 2023-03-21 16:03:27
 * @LastEditors: dushuai
 * @LastEditTime: 2023-04-21 17:18:08
 * @description: 首页 --> 页面组件
-->
<script setup lang='ts'>
import Loading from './Home/Loading.vue'
import Button from './Home/Button.vue'

interface Tab {
  name: string
}
const tabs = ref<Tab[]>([
  { name: 'Loading' },
  { name: 'Button' },
])
const curTab = ref<string>('Loading')
function handleTabChange(tab: Tab) {
  if (curTab.value !== tab.name) curTab.value = tab.name
}
</script>
<template>
  <div class="tabs">
    <div :class="['tab-item', curTab === tab.name ? 'tab-item--active' : '']" v-for="(tab, index) in tabs" :key="index"
      @click="handleTabChange(tab)">
      {{ tab.name }}</div>
  </div>

  <Loading v-if="curTab === 'Loading'" />
  <Button v-if="curTab === 'Button'" />
</template>
<style lang='less' scoped>
.tabs {
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin-bottom: 50px;
  position: sticky;
  top: 0;
  background: #fff;
  width: 100%;
  z-index: 1;
  padding-bottom: 30px;

  .tab-item {
    padding: 10px 15px;
    background: rgba(0, 0, 0, 0.1);
  }

  .tab-item--active {
    background: rgba(255, 0, 0, 0.3);
  }
}
</style>
