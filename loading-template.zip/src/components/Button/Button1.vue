<script setup lang='ts'>

</script>
<template>
  Button1
</template>
<style lang='less' scoped></style>
