/*
 * @Author: dushuai
 * @Date: 2023-03-17 09:30:38
 * @LastEditors: dushuai
 * @LastEditTime: 2023-03-23 16:40:12
 * @description: 自定义ts声明文件
 */
/// <reference types="vite/client" />

declare module 'cmblapi'
